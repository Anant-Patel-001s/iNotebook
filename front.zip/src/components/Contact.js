import React from 'react'

function Contact() {
  return (
    <div>
        <h1>Contact Us Page</h1>
    </div>
  )
}

export default Contact