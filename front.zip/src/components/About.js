import React, { useContext, useEffect } from 'react'

function About() {
  return (
    <div>
      This is About
    </div>
  )
}

export default About