import React from 'react'
import './Header.css'
function Header() {
  return (
    <div>
      <h1 style={{ backgroundColor: 'gray', color: 'aqua', padding: '1rem', alignItems: 'center'}}>iNotebook</h1>
    </div>
  )
}

export default Header; 