import React, { useState } from 'react'
import NoteContext from './noteContext'

const NoteState = (props) => {
    const notesInitial = [
        {
            "_id": "63a0103d9e56e178c3eda1f2",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:18:21.840Z",
            "__v": 0
        },
        {
            "_id": "63a012fdac56796a5c67da63",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:30:05.799Z",
            "__v": 0
        },
        {
            "_id": "63a012fdac56796a5c67da63",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:30:05.799Z",
            "__v": 0
        },
        {
            "_id": "63a012fdac56796a5c67da63",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:30:05.799Z",
            "__v": 0
        },
        {
            "_id": "63a012fdac56796a5c67da63",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:30:05.799Z",
            "__v": 0
        },
        {
            "_id": "63a012fdac56796a5c67da63",
            "user": "639c6398646f8888df66e388",
            "title": "My Title",
            "description": "Plsease wake up",
            "tag": "Personal",
            "date": "2022-12-19T07:30:05.799Z",
            "__v": 0
        }
    ]

    const [notes, setNotes] = useState(notesInitial)
    return (
        <NoteContext.Provider value={{ notes, setNotes }}>
            {props.children}
        </NoteContext.Provider>
    )
}

export default NoteState;